# streamlit_app.py
import pandas as pd
import streamlit as st

from data_prep import nice_last_modified, prep_df
from drive_io import (
    index_images_by_camera,
    load_events_from_drive,
    _drive_client,
    _download_drive_file_bytes,
)
from ui_components import inject_css, render_patterns, render_timeline, render_listing_and_viewer


# ---------------------------
# Config
# ---------------------------
st.set_page_config(page_title="Ranch Events | Wildlife Monitoring", page_icon="🦌", layout="wide")
inject_css()

ADV_GALLERY_URL = "https://willclo1.github.io/SpyPointAdvancedGallery/"

# --- Top nav CSS (ranch wildlife theme) ---
st.markdown(
    """
    <style>
      .top-nav {
        display: flex;
        justify-content: center;
        margin-top: 0.6rem;
        margin-bottom: 1.1rem;
      }
      .top-nav-inner {
        width: 100%;
        max-width: 980px;
      }
      .top-nav-inner button {
        height: 56px;
        font-size: 1.05rem !important;
        font-weight: 700 !important;
        letter-spacing: 0.02em;
        border-radius: 16px !important;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
      }
      .nav-divider {
        height: 1px;
        background: linear-gradient(
          90deg,
          transparent,
          rgba(245, 241, 234, 0.18),
          transparent
        );
        margin-bottom: 1.4rem;
      }
      /* Embed styling */
      .embed-wrap {
        border-radius: 24px;
        overflow: hidden;
        border: 1px solid rgba(245, 241, 234, 0.22);
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.35);
      }
      
      /* Brand header */
      .brand-header {
        display: flex;
        align-items: center;
        gap: 1rem;
        margin-bottom: 1.5rem;
        padding: 1rem 0;
      }
      
      .brand-logo {
        width: 52px;
        height: 52px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2rem;
        background: linear-gradient(135deg, #8a9a5b 0%, #4a5d3f 100%);
        border-radius: 14px;
        box-shadow: 0 4px 16px rgba(138, 154, 91, 0.3);
      }
      
      .brand-text {
        display: flex;
        flex-direction: column;
        gap: 0.15rem;
      }
      
      .brand-title {
        font-family: 'Crimson Pro', Georgia, serif;
        font-size: 1.8rem;
        font-weight: 900;
        letter-spacing: -0.02em;
        line-height: 1;
        background: linear-gradient(135deg, #f5f1ea 0%, #c4a77d 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
      }
      
      .brand-subtitle {
        font-size: 0.8rem;
        color: rgba(245, 241, 234, 0.7);
        letter-spacing: 0.05em;
        text-transform: uppercase;
        font-weight: 500;
      }
    </style>
    """,
    unsafe_allow_html=True,
)

# ---------------------------
# Session state
# ---------------------------
if "current_view" not in st.session_state:
    st.session_state.current_view = "dashboard"
if "gallery_limit" not in st.session_state:
    st.session_state.gallery_limit = 8


def _require_secret(path: str):
    parts = path.split(".")
    cur = st.secrets
    for p in parts:
        if p not in cur:
            raise KeyError(f"Missing secret: {path}")
        cur = cur[p]
    return cur


@st.cache_data(show_spinner=False)
def prepare_events(raw_df):
    return prep_df(raw_df)


DRIVE_FILE_ID = _require_secret("gdrive.file_id")
ROOT_FOLDER_ID = _require_secret("gdrive.root_folder_id")
CACHE_TTL_SECONDS = int(st.secrets.get("cache_ttl_seconds", 6 * 60 * 60))


# ---------------------------
# Brand Header
# ---------------------------
st.markdown(
    """
    <div class="brand-header">
        <div class="brand-logo">🦌</div>
        <div class="brand-text">
            <div class="brand-title">Ranch Events</div>
            <div class="brand-subtitle">Wildlife Monitoring System</div>
        </div>
    </div>
    """,
    unsafe_allow_html=True
)

# ---------------------------
# Load data + index images
# ---------------------------
with st.spinner("Loading events..."):
    raw = load_events_from_drive(DRIVE_FILE_ID)
df = prepare_events(raw)

last_mod_pretty = nice_last_modified(raw.attrs.get("drive_modified", ""))

# ---------------------------
# TOP VIEW SELECTOR (3 tabs)
# ---------------------------
st.markdown('<div class="top-nav"><div class="top-nav-inner">', unsafe_allow_html=True)

nav1, nav2, nav3 = st.columns([1, 1, 1], gap="large")

with nav1:
    if st.button(
        "📊 Data Dashboard",
        width="stretch",
        type="primary" if st.session_state.current_view == "dashboard" else "secondary",
        key="nav_dashboard",
    ):
        st.session_state.current_view = "dashboard"
        st.rerun()

with nav2:
    if st.button(
        "📸 Photo Browser",
        width="stretch",
        type="primary" if st.session_state.current_view == "photos" else "secondary",
        key="nav_photos",
    ):
        st.session_state.current_view = "photos"
        st.rerun()

with nav3:
    if st.button(
        "🦌 Advanced Gallery",
        width="stretch",
        type="primary" if st.session_state.current_view == "gallery" else "secondary",
        key="nav_gallery",
    ):
        st.session_state.current_view = "gallery"
        st.rerun()

st.markdown("</div></div>", unsafe_allow_html=True)
st.markdown("<div class='nav-divider'></div>", unsafe_allow_html=True)


# ---------------------------
# Render appropriate view
# ---------------------------
if st.session_state.current_view == "dashboard":
    st.title("Ranch Activity Dashboard")
    st.caption("Wildlife, people, and vehicle monitoring system")

    st.markdown(
        f'<div class="data-status"><strong>{len(df):,}</strong> events available '
        f'<span>• Updated {last_mod_pretty}</span></div>',
        unsafe_allow_html=True,
    )

    # ---------------------------
    # Sidebar filters for Data Dashboard ONLY
    # ---------------------------
    with st.sidebar:
        st.header("Dashboard Filters")
        section = st.radio("Category", ["Wildlife", "People", "Vehicles"], index=0, key="dash_section")

        camera_options = sorted([c for c in df["camera"].dropna().unique().tolist() if c])
        selected_cameras = (
            st.multiselect("Cameras", options=camera_options, default=camera_options, key="dash_cameras")
            if camera_options
            else []
        )

        valid_dt = df.dropna(subset=["datetime"])
        if valid_dt.empty:
            st.error("No valid date/time data found in events file")
            st.stop()

        min_dt = valid_dt["datetime"].min()
        max_dt = valid_dt["datetime"].max()

        date_range = st.date_input(
            "Date Range",
            value=(min_dt.date(), max_dt.date()),
            min_value=min_dt.date(),
            max_value=max_dt.date(),
            key="dash_dates",
        )

        temp_series = valid_dt["temp_f"].dropna()
        temp_range = None
        if not temp_series.empty:
            tmin = int(temp_series.min())
            tmax = int(temp_series.max())
            if tmin == tmax:
                tmin -= 1
                tmax += 1
            temp_range = st.slider(
                "Temperature (°F)",
                min_value=tmin,
                max_value=tmax,
                value=(tmin, tmax),
                key="dash_temp",
            )

        # Moon phase filter
        selected_moon_phases = []
        if "moon_phase_clean" in df.columns:
            moon_phases = sorted([p for p in df["moon_phase_clean"].unique().tolist() if p])
            if moon_phases:
                selected_moon_phases = st.multiselect(
                    "🌙 Moon Phases",
                    options=moon_phases,
                    default=[],
                    key="dash_moon_phases",
                )

        # Wildlife-only filters
        species_filter = []
        include_other = False
        bar_style = "Stacked"
        time_gran = "Hour"

        if section == "Wildlife":
            st.markdown("---")
            st.markdown("**Wildlife Options**")
            include_other = st.checkbox("Include 'Other'", value=False, key="dash_include_other")
            bar_style = st.radio("Chart Style", ["Stacked", "Grouped"], index=0, key="dash_bar_style")
            time_gran = st.selectbox("Time Granularity", ["Hour", "2-hour", "4-hour"], index=0, key="dash_time_gran")

            wild_pool = df[df["event_type"] == "animal"].copy()
            if not include_other:
                wild_pool = wild_pool[wild_pool["wildlife_label"] != "Other"]

            sp_opts = sorted([s for s in wild_pool["wildlife_label"].unique().tolist() if s])
            if sp_opts:
                species_filter = st.multiselect("Filter Animals", options=sp_opts, default=[], key="dash_species")

        st.markdown("---")
        st.markdown(f'<div class="small-muted">Cache TTL: {CACHE_TTL_SECONDS//3600}h</div>', unsafe_allow_html=True)
        if st.button("Refresh data", key=f"refresh_{st.session_state.current_view}", width="stretch"):
            st.cache_data.clear()
            st.rerun()

    # ---------------------------
    # Apply filters
    # ---------------------------
    base = df.dropna(subset=["datetime"]).copy()

    if selected_cameras:
        base = base[base["camera"].isin(selected_cameras)]

    if section == "Wildlife":
        base = base[base["event_type"] == "animal"].copy()
        if not include_other:
            base = base[base["wildlife_label"] != "Other"]
    elif section == "People":
        base = base[base["event_type"] == "human"].copy()
    else:
        base = base[base["event_type"] == "vehicle"].copy()

    start, end = date_range
    start_ts = pd.Timestamp(start)
    end_ts = pd.Timestamp(end) + pd.Timedelta(days=1)
    base = base[(base["datetime"] >= start_ts) & (base["datetime"] < end_ts)]

    if temp_range is not None:
        lo, hi = temp_range
        base = base[base["temp_f"].notna()]
        base = base[(base["temp_f"] >= lo) & (base["temp_f"] <= hi)]

    if selected_moon_phases and "moon_phase_clean" in base.columns:
        base = base[base["moon_phase_clean"].isin(selected_moon_phases)]

    if section == "Wildlife" and species_filter:
        base = base[base["wildlife_label"].isin(species_filter)]

    if base.empty:
        st.info("No events match the current filters")
        st.stop()

    # ---------------------------
    # KPIs
    # ---------------------------
    active_cameras = base["camera"].nunique()
    avg_temp = base["temp_f"].mean()
    peak_hour = base["datetime"].dt.hour.mode()
    peak_label = "—" if peak_hour.empty else pd.Timestamp(2000, 1, 1, int(peak_hour.iloc[0])).strftime("%-I %p")

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("Sightings", f"{len(base):,}")
    k2.metric("Active Cameras", f"{active_cameras:,}")
    k3.metric("Average Temp", "—" if pd.isna(avg_temp) else f"{avg_temp:.0f}°F")
    k4.metric("Peak Activity", peak_label)

    st.markdown("---")

    # ---------------------------
    # Data Visualizations
    # ---------------------------
    render_timeline(base, section)
    st.markdown("---")
    render_patterns(base, section, include_other, bar_style, time_gran)

    # Footer
    st.divider()
    st.caption(
        f"Data source: {raw.attrs.get('drive_name','events.csv')} • "
        f"Updated: {last_mod_pretty} • "
        f"Cache: {CACHE_TTL_SECONDS//3600}h"
    )

elif st.session_state.current_view == "gallery":
    # Sidebar: minimal + link out
    with st.sidebar:
        st.header("Advanced Gallery")
        st.markdown(f"[Open in new tab ↗]({ADV_GALLERY_URL})")
        st.markdown("---")
        st.markdown(f'<div class="small-muted">Cache TTL: {CACHE_TTL_SECONDS//3600}h</div>', unsafe_allow_html=True)
        if st.button("Refresh data", key=f"refresh_{st.session_state.current_view}", width="stretch"):
            st.cache_data.clear()
            st.rerun()

    st.title("Advanced Gallery")
    st.caption("Grouped sightings as events")

    # Big, clean embed
    st.markdown('<div class="embed-wrap">', unsafe_allow_html=True)
    st.components.v1.iframe(ADV_GALLERY_URL, height=1400, scrolling=True)
    st.markdown("</div>", unsafe_allow_html=True)

else:  # photos view
    # Clear sidebar for photos tab
    with st.sidebar:
        st.info("📸 Photo Browser filters are shown in the main area above")
        st.markdown("---")
        st.markdown(f'<div class="small-muted">Cache TTL: {CACHE_TTL_SECONDS//3600}h</div>', unsafe_allow_html=True)
        if st.button("Refresh data", key=f"refresh_{st.session_state.current_view}", width="stretch"):
            st.cache_data.clear()
            st.rerun()

    st.title("Photo Browser")
    st.caption("Browse and view individual sightings")

    # ---------------------------
    # Inline Filters (not in sidebar)
    # ---------------------------
    st.markdown("### Filters")

    filter_col1, filter_col2, filter_col3 = st.columns(3)

    with filter_col1:
        section_photos = st.selectbox("Category", ["Wildlife", "People", "Vehicles"], index=0, key="photo_section")

    with filter_col2:
        camera_options_photos = sorted([c for c in df["camera"].dropna().unique().tolist() if c])
        if camera_options_photos:
            selected_cameras_photos = st.multiselect(
                "Cameras",
                options=camera_options_photos,
                default=camera_options_photos,
                key="photo_cameras",
            )
        else:
            selected_cameras_photos = []

    with filter_col3:
        valid_dt_photos = df.dropna(subset=["datetime"])
        if not valid_dt_photos.empty:
            min_dt_photos = valid_dt_photos["datetime"].min()
            max_dt_photos = valid_dt_photos["datetime"].max()

            date_range_photos = st.date_input(
                "Date Range",
                value=(min_dt_photos.date(), max_dt_photos.date()),
                min_value=min_dt_photos.date(),
                max_value=max_dt_photos.date(),
                key="photo_dates",
            )

    # Additional filters row
    filter_col4, filter_col5, filter_col6 = st.columns(3)

    temp_range_photos = None
    if not valid_dt_photos.empty:
        temp_series_photos = valid_dt_photos["temp_f"].dropna()
        if not temp_series_photos.empty:
            with filter_col4:
                tmin_photos = int(temp_series_photos.min())
                tmax_photos = int(temp_series_photos.max())
                if tmin_photos == tmax_photos:
                    tmin_photos -= 1
                    tmax_photos += 1
                temp_range_photos = st.slider(
                    "Temperature (°F)",
                    min_value=tmin_photos,
                    max_value=tmax_photos,
                    value=(tmin_photos, tmax_photos),
                    key="photo_temp",
                )

    # Moon phase filter for photos
    selected_moon_phases_photos = []
    if "moon_phase_clean" in df.columns:
        moon_phases_photos = sorted([p for p in df["moon_phase_clean"].unique().tolist() if p])
        if moon_phases_photos:
            with filter_col5:
                selected_moon_phases_photos = st.multiselect(
                    "🌙 Moon Phases",
                    options=moon_phases_photos,
                    default=[],
                    key="photo_moon_phases",
                )

    # Wildlife-specific filters
    species_filter_photos = []
    include_other_photos = False

    if section_photos == "Wildlife":
        with filter_col6:
            include_other_photos = st.checkbox("Include 'Other'", value=False, key="photo_include_other")

        filter_col7, _ = st.columns([1, 2])
        wild_pool_photos = df[df["event_type"] == "animal"].copy()
        if not include_other_photos:
            wild_pool_photos = wild_pool_photos[wild_pool_photos["wildlife_label"] != "Other"]

        sp_opts_photos = sorted([s for s in wild_pool_photos["wildlife_label"].unique().tolist() if s])
        if sp_opts_photos:
            with filter_col7:
                species_filter_photos = st.multiselect(
                    "Animals",
                    options=sp_opts_photos,
                    default=[],
                    key="photo_species",
                )

    st.markdown("---")

    # Apply filters for photos
    base_photos = df.dropna(subset=["datetime"]).copy()

    if selected_cameras_photos:
        base_photos = base_photos[base_photos["camera"].isin(selected_cameras_photos)]

    if section_photos == "Wildlife":
        base_photos = base_photos[base_photos["event_type"] == "animal"].copy()
        if not include_other_photos:
            base_photos = base_photos[base_photos["wildlife_label"] != "Other"]
    elif section_photos == "People":
        base_photos = base_photos[base_photos["event_type"] == "human"].copy()
    else:
        base_photos = base_photos[base_photos["event_type"] == "vehicle"].copy()

    start_photos, end_photos = date_range_photos
    start_photos_ts = pd.Timestamp(start_photos)
    end_photos_ts = pd.Timestamp(end_photos) + pd.Timedelta(days=1)
    base_photos = base_photos[
        (base_photos["datetime"] >= start_photos_ts) & (base_photos["datetime"] < end_photos_ts)
    ]

    if temp_range_photos is not None:
        lo_photos, hi_photos = temp_range_photos
        base_photos = base_photos[base_photos["temp_f"].notna()]
        base_photos = base_photos[(base_photos["temp_f"] >= lo_photos) & (base_photos["temp_f"] <= hi_photos)]

    if selected_moon_phases_photos and "moon_phase_clean" in base_photos.columns:
        base_photos = base_photos[base_photos["moon_phase_clean"].isin(selected_moon_phases_photos)]

    if section_photos == "Wildlife" and species_filter_photos:
        base_photos = base_photos[base_photos["wildlife_label"].isin(species_filter_photos)]

    st.info(f"Showing {len(base_photos):,} sightings")

    visible_cameras = tuple(sorted(base_photos["camera"].dropna().unique().tolist()))
    with st.spinner("Loading photo index..."):
        image_index = index_images_by_camera(ROOT_FOLDER_ID, visible_cameras)

    if not image_index:
        st.warning("No matching camera folders or photos were found in Google Drive.")

    render_listing_and_viewer(
        base=base_photos,
        section=section_photos,
        include_other=include_other_photos,
        image_index=image_index,
        drive_client_factory=_drive_client,
        download_bytes_func=_download_drive_file_bytes,
    )
